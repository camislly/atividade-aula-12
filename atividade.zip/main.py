#============atividade 2============

nota1 = float(input('Insira a nota 1: ').replace(',','.'))
nota2 = float(input('Insira a nota 2: ').replace(',','.'))
nota3 = float(input('Insira a nota 3: ').replace(',','.'))
nota4 = float(input('Insira a nota 4: ').replace(',','.'))
         
média = (nota1+nota2+nota3+nota4)/4
print("A média do aluno é ",média)
print('\n\n')

#============atividade 1===============
print('----Conversor Metros para Centímetros----')

m = float(input('Insira a medida em metros: ').replace(',','.'))
c = m * 100
print('Centímetros : {:.2f}'.format(c))
